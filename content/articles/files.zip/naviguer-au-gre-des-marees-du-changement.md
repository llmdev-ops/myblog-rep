---
title: "Naviguer au gré des marées du changement"
pillar: "Robustesse & Transformation"
date: 2023-08-07
excerpt: "Dans un monde V.U.C.A., cinq entreprises illustrent comment pivoter avec succès."
readtime: "9"
status: published
---

> Cet article est disponible en version HTML sur /articles/naviguer-au-gre-des-marees-du-changement.html

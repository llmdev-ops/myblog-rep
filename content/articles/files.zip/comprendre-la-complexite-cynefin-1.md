---
title: "Cynefin — 1 : origines et domaines"
pillar: "Robustesse & Transformation"
date: 2023-08-02
excerpt: "Le modèle Cynefin aide à comprendre la nature complexe et évolutive des situations."
readtime: "5"
status: published
---

> Cet article est disponible en version HTML sur /articles/comprendre-la-complexite-cynefin-1.html

---
title: "Le changement n'est pas un projet (et c'est pour ça qu'il échoue)"
pillar: "Robustesse & Transformation"
date: 2025-05-30
excerpt: "Définir une date de fin pour une transformation réelle, c'est déjà lui donner les conditions de son échec."
readtime: "9"
status: published
---

> Cet article est disponible en version HTML sur /articles/changement-pas-un-projet.html

---
title: "Cynefin — 2 : décryptage des domaines"
pillar: "Robustesse & Transformation"
date: 2023-08-03
excerpt: "Exemples concrets pour chaque domaine de Cynefin avec les signaux d'alerte et les recommandations associées."
readtime: "7"
status: published
---

> Cet article est disponible en version HTML sur /articles/comprendre-la-complexite-cynefin-2.html

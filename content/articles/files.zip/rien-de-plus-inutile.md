---
title: "Rien de plus inutile"
pillar: "Performance & Valeur"
date: 2021-01-26
excerpt: "Peter Drucker : rien de plus inutile que de faire avec efficacité quelque chose qui ne devrait pas être fait."
readtime: "6"
status: published
---

> Cet article est disponible en version HTML sur /articles/rien-de-plus-inutile.html

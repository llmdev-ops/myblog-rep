---
title: "REX impact mapping SOPO 2019"
pillar: "Organisation & Delivery"
date: 2019-02-04
excerpt: "Co-animer un atelier sur l'Impact mapping à la School of Product Ownership."
readtime: "5"
status: published
---

> Cet article est disponible en version HTML sur /articles/rex-impact-mapping-sopo-2019.html

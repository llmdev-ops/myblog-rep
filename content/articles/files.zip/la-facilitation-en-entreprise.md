---
title: "La facilitation en entreprise"
pillar: "Organisation & Delivery"
date: 2022-02-01
excerpt: "La facilitation devient incontournable. Origines, définition, et situations concrètes."
readtime: "6"
status: published
---

> Cet article est disponible en version HTML sur /articles/la-facilitation-en-entreprise.html

---
title: "Se préparer à faciliter en 30 questions"
pillar: "Organisation & Delivery"
date: 2022-02-09
excerpt: "Mon protocole de préparation complet : objectif, produit, participants, processus, lieu."
readtime: "8"
status: published
---

> Cet article est disponible en version HTML sur /articles/se-preparer-a-faciliter-en-30-questions.html
